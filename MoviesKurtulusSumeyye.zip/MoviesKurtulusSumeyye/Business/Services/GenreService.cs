﻿using DataAccess;

namespace Business;

public interface IGenreService {
    IQueryable<GenreModel> Query();

}

public class GenreService: IGenreService
{
    private readonly Db _db;

    public GenreService(Db db)
    {   
        _db = db;
    }

    public IQueryable<GenreModel> Query()
    {
        return _db.Genres.OrderBy(a => a.Name).Select(a => new GenreModel()
        {
            Name = a.Name
        });
    }
}
