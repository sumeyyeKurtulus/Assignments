﻿#nullable disable
using System.ComponentModel;
using DataAccess;

namespace Business;

public class DirectorModel: Record
{
    public string Name { get; set; }
    public string Surname { get; set; }

    [DisplayName("Birth Date")]
    public DateTime BirthDate { get; set; }

    public bool IsRetired { get; set; }
}
