﻿#nullable disable
using DataAccess;

namespace Business;

public class GenreModel
{
    public string Name { get; set; }
    // public  List<Movie> Movies { get; set; }
}
