﻿using Microsoft.EntityFrameworkCore;

namespace DataAccess;

public class Db: DbContext
{

    public DbSet<Director> Directors { get; set; }
    public DbSet<Movie> Movies { get; set; }
    public DbSet<Genre> Genres { get; set; }
    public DbSet<MovieGenre> MovieGenres { get; set; }

  //here is we use DEPENDENCY INJECTION ---- the most important one!!!!
    public Db(DbContextOptions options): base(options) //the same approach with super; we will store connection str here
    {
        
    }

    //only virtual methods can be overridden
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<MovieGenre>().HasKey(e => new { e.MovieId, e.GenreId });
    }

    // protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    // {
    //     optionsBuilder.UseMySQL("server=localhost;user=root;password=password;database=BlogDB");
    // }
}
