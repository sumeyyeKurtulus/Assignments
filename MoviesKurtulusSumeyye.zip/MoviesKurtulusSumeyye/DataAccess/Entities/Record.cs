﻿#nullable disable
namespace DataAccess;

public abstract class Record
{   
    public int Id { get; set; }
    public string GuId { get; set; }
}
