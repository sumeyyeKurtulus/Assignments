﻿#nullable disable
namespace DataAccess;

public class Genre: Record
{
    public string Name { get; set; }

    //Relations
    public  List<Movie> Movies { get; set; }
}
