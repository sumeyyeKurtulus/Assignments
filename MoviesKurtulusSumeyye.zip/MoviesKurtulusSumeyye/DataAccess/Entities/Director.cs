﻿#nullable disable
namespace DataAccess;

public class Director: Record
{
    public string Name { get; set; }
    public string Surname { get; set; }

    public DateTime BirthDate { get; set; }

    public bool IsRetired { get; set; }

    //Relations
    public  List<Movie> Movies { get; set; }
}
