﻿#nullable disable
using System.ComponentModel.DataAnnotations;

namespace DataAccess;

public class Grade
{
    public int Id { get; set; }
    [Required]
    [MaxLength(11)]
    public string Year { get; set; }

    public List<Student> Students { get; set; }

    // one student can have one grade, one grade can have many students
}
