﻿#nullable disable
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using DataAccess;

namespace Business;

public class StudentModel
{
    public int Id { get; set; }

    public string Name { get; set; }

    [Required]
    [MaxLength(50)]
    public string Surname { get; set; }

    [DisplayName("Full Name")]
    public string FullNameOutput { get; set; }

    [DisplayName("Grade")]
    //TODO get back over here
    public string GradeOutput { get; set; }

    [DisplayName("University Exam Rank")]
    public int? UniversityExamRank { get; set; }

    [DisplayName("Cumulative GPA")]
    public decimal? CumulativeGpa { get; set; }
    
    public int GradeId { get; set; }
}
