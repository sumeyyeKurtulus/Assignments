﻿using DataAccess;

namespace Business;

public interface IGradeService {
    IQueryable<GradeModel> Query();
}

public class GradeService: IGradeService
{
    private readonly Db _db;
    
    public GradeService(Db db)
    {
        _db = db;
    }

    public IQueryable<GradeModel> Query()
    {
        return _db.Grades.Select(a => new GradeModel()
        {
            Id = a.Id,
            Year = a.Year
        });
    }
}
